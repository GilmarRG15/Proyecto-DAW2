<?php include VIEWS_PATH . '/layouts/header.php'; ?>

<div class="error-container">
    <h1>404</h1>
    <p>Página no encontrada</p>
    <a href="<?= url('/') ?>" class="btn btn-primary">Volver al Inicio</a>
</div>

<?php include VIEWS_PATH . '/layouts/footer.php'; ?>
